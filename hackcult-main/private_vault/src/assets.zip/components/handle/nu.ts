// const handleShare = (id: string) => {
//     setSharingFileId(id);
//     setShareEmail("");
//   };


// const handleDelete = (id: string) => {
//     setFiles(files.filter((file) => file.id !== id));
// };

// const handleReceiveNext = () => {
//     setReceiveStep(2);
//   };

// const handleReceiveFile = () => {
//     console.log("Receiving file:", {
//       receiveEmail,
//       receiveFileName,
//       securityKey1,
//       securityKey2,
//     });
//     setIsReceiving(false);
//     setReceiveStep(1);
//     setReceiveEmail("");
//     setReceiveFileName("");
//     setSecurityKey1("");
//     setSecurityKey2("");
//   };

 // async function f(){
  //   const response = await axios.get("http://localhost:3000/give");
  //   console.log(response.data);
  //   const encryptedDataArray = new Uint8Array(Object.values(response.data));

  //     // Log the received encrypted data
  //     console.log("Received encrypted data:", encryptedDataArray);
  //     decryptFile(encryptedDataArray,nonce,key)
  // }
